import 'package:get/get.dart';

class CallController extends GetxController {}
