class AppImage {
  // static var icon1 = 'assets/image/icon1.png';
 
}
