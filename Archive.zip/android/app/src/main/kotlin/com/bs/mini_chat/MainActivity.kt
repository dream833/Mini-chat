package com.bs.mini_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
